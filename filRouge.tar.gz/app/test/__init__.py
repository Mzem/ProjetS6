import sys, os
cwd = os.getcwd()
sys.path.insert(0, cwd)
