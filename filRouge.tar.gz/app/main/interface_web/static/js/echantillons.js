//Message d'attente chargement
$(document).ready(function(){
	$("#loading").fadeOut()
});

