******************************************
choixFichier.py
******************************************

.. automodule:: interface_web.choixFichier

.. autofunction:: FileWithSGF

.. autofunction:: FileWithDragDrop

.. raw:: latex
    \clearpage