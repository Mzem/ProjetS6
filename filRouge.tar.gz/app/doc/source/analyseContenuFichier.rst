************************
analyseContenuFichier.py
************************

.. automodule:: chargement_des_donnees.analyseContenuFichier

.. autofunction:: lecture

.. autofunction:: typeDeDonnee

.. autofunction:: removeDateSuffix

.. autofunction:: descriptionColonnes

.. autofunction:: analyseFichier