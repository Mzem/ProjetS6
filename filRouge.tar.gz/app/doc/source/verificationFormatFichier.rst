*****************************
verificationFormatFichier.py
*****************************

.. automodule:: chargement_des_donnees.verificationFormatFichier

.. autofunction:: verifExistence

.. autofunction:: verifExtension

.. autofunction:: verifLecture

.. autofunction:: verifCSV

.. autofunction:: ouvrir
