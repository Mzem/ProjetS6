******************************************
addQuantitativesContinues.py
******************************************

.. automodule:: add.addQuantitativesContinues

.. autofunction:: discretisation

.. autofunction:: calculNombreClasses

.. autofunction:: preparationIntervallesAnalyse

.. autofunction:: interpolationLineaire

.. autofunction:: quantileContinu

.. autofunction:: anomaliesTukeyContinu

.. autofunction:: infoDistributionCumulativeContinue

.. autofunction:: infoBoiteTukeyContinu

.. autofunction:: infoStats
