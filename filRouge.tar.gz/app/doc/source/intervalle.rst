************************
intervalle.py
************************

.. automodule:: add.intervalle

La classe intervalle.py
=======================

.. autoclass:: Intervalle
	:members:

Les fonctions
=============

.. autofunction:: rechercheIntervalle
