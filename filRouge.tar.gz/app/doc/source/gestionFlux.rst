************************
gestionFlux.py
************************

.. automodule:: interface_web.gestionFlux

.. autofunction:: fenetre_choix_fichier

.. autofunction:: fenetre_role_choix_colonne

.. autofunction:: fenetre_resultat_ADD

.. autofunction:: remove

.. autofunction:: removeFiles

.. autofunction:: manuel

.. autofunction:: sauvegardeResultats