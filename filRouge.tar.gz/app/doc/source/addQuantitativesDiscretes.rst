******************************************
addQuantitativesDiscretes.py
******************************************

.. automodule:: add.addQuantitativesDiscretes

.. autofunction:: moyenne

.. autofunction:: quantileDiscret

.. autofunction:: variance

.. autofunction:: ecartType

.. autofunction:: anomaliesTukeyDiscret

.. autofunction:: symetrie

.. autofunction:: aplatissement

.. autofunction:: infoDistribution

.. autofunction:: infoDistributionCumulativeDiscrete

.. autofunction:: infoBoiteTukeyDiscret
