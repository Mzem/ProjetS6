******************************************
addQualitatives.py
******************************************

.. automodule:: add.addQualitatives

.. autofunction:: nbElemListeCouple

.. autofunction:: calculEffectifs

.. autofunction:: calculEffectifsCumules

.. autofunction:: calculFrequences

.. autofunction:: calculFrequencesCumulees

.. autofunction:: infoSecteurs

.. autofunction:: infoHistogramme